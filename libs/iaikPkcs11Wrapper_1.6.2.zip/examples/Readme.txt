Some of the examples in this package need the IAIK JCE library (iaik_jce.jar) to 
compile and run. If you have Java 1.2 or 1.3, you may also need a JCE 
framework implementation (e.g. iaik_javax_crypto.jar). Put the jar-files in the 
"lib" directory.

Evaluation versions of these IAIK libraries can be downloaded from 
http://jce.iaik.tugraz.at. 
